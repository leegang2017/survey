import { ApiProperty } from "@nestjs/swagger";

// @ApiProperty()
// count:number;
// @ApiProperty()
// page:number;
// @ApiProperty()
// pageSize:number;
// @ApiProperty({type: [T] })
// content:T[];

export const ListPage = ()=> {
    return  {
        type: 'array',
        items: {
          type: 'array',
          items: {
            type: 'number',
          },
        },
    }
  }